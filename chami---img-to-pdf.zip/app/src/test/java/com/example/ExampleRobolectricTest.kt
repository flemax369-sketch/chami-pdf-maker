package com.chami.pdfmaker

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.chami.pdfmaker.theme.ChamiThemes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Chami - Img to PDF", appName)
  }

  @Test
  fun `verify themes loaded`() {
    val themes = ChamiThemes.ALL
    assertEquals(2, themes.size)
    assertNotNull(ChamiThemes.byId("obsidian_amoled"))
    assertNotNull(ChamiThemes.byId("emerald_pro"))
  }
}
